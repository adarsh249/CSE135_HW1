<?php

namespace Piwik\Scheduler;

use Piwik\Exception\Exception;

class RetryableException extends Exception
{
}
