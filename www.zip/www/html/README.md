# CSE135_HW1
<https://cse151group111.online>

## Team Members:
- Adarsh Patel
- Bill (Yunze) Xie
- Gary Lin

## Grader password
password: `123`

SSH Private Key below or in id_rsa file given.

`-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAABlwAAAAdzc2gtcn
NhAAAAAwEAAQAAAYEApRWqpXyljKEYgru1ArX7igDK2Ys+26dfY/j3xLXtSS8gFDfx6I2K
DS3rRzcK0xWPx9VYY/ucgh3KSatUs7w2DQpTvHunVU1EGXyUUrDLq55cUVmtq8AMxwKjnZ
9FkCm3E780rfnugV709XoF3248jn7cb586RDrYxMbQxV6rEyA4tOn04HOLmfZVKqfVKuRO
cQ9uIUUoBgG1fyAJIp5iVboGowe+riJ8tzAdRcT6ZS5pIRhmywNbWfv7Ntg7kfdW7q6M/L
uxMfAjOogEgq1HK0dRvOZY8boZqmzvJk6SRagALSg+ltjRSwxAePJ4c72RDIiMJPZA/gXO
KchLar65ksDK4roKymB7Y3rLl1ERTg46hUIM2O53Dam8bBL0YChMpNlA073rHSsZTH+kSi
YKfliS/qc5KdJsAT2vMOgM7gnq9UK70zjB2Ckwtp8+ZDSB61iNK/ep6IeCNsSSRIeJEXr4
oxuhnxyd1Pu4s9ShzFtrTOA0xFbL8s7LqKS2Fz51AAAFkPmfJwX5nycFAAAAB3NzaC1yc2
EAAAGBAKUVqqV8pYyhGIK7tQK1+4oAytmLPtunX2P498S17UkvIBQ38eiNig0t60c3CtMV
j8fVWGP7nIIdykmrVLO8Ng0KU7x7p1VNRBl8lFKwy6ueXFFZravADMcCo52fRZAptxO/NK
357oFe9PV6Bd9uPI5+3G+fOkQ62MTG0MVeqxMgOLTp9OBzi5n2VSqn1SrkTnEPbiFFKAYB
tX8gCSKeYlW6BqMHvq4ifLcwHUXE+mUuaSEYZssDW1n7+zbYO5H3Vu6ujPy7sTHwIzqIBI
KtRytHUbzmWPG6Gaps7yZOkkWoAC0oPpbY0UsMQHjyeHO9kQyIjCT2QP4FzinIS2q+uZLA
yuK6Cspge2N6y5dREU4OOoVCDNjudw2pvGwS9GAoTKTZQNO96x0rGUx/pEomCn5Ykv6nOS
nSbAE9rzDoDO4J6vVCu9M4wdgpMLafPmQ0getYjSv3qeiHgjbEkkSHiRF6+KMboZ8cndT7
uLPUocxba0zgNMRWy/LOy6ikthc+dQAAAAMBAAEAAAGAfBQe4KchHuPuMkS3NkRlvUH/NS
dNpXbVYaS9RWKf6IO9DrVF406O1n0O+8XJIwJvwPj/qJZy+fE+G8TksvrhfUenzGD8Ukby
yl0ydjxfuKwcIyDOQerlL6cyJsSRWlugOP1bsO/Lbf1bDC4cv+RxK4D6WgNJngLE7pGoVN
BksMllFcVKwnDWGnBlbtwaglR7CMtaMTNzc6BRNC118EkvC9P4LQ0jKmrNZjqJpej5cpdB
eRiIGkp5nNah6IT5sSo/PZbS/e1szxtY7q0va03Vvsh8o4P9jChRUstKhKkKRRnLRYCVYq
1uizfOEZlYlsTlLpqKcvpXRCyhD3QguAq26jfsIFP2jQLw7ZcfJGi2AcfEml4HJ6L6/qK1
ez0pWXPiv9cMDFGUg4fCjav6L3cpqDQeRkz03YzhYIXivB+XDdrZDmS9jmX9rjNtFCDPUX
WFdcJpRLtQjIfXA5MWgl/tiHDuoSFbbwPvtiXwWD4jSLpCE7MTRxpeGL0/c5C0S8UBAAAA
wQCzNRh7rjUhnEiKxWd5izm3D4ewueqnLifrnbtjMWNoNDUFOpzNO4Hv3nBeuPh4SIQ5Hu
EsD0vPnCSCe1NieEg8u+/M6lVgbdoewco9PcxanN7WInxqi2y4OCfIylt5Z103W1uEfmlR
WwUtF8nGvZsA5BzXG2rWbZVLgvyhtzMzRha1/Z8p01W+Y3EXKYn5ywHr6D2PKYr5EaHd/B
0Ad8va4bI5VcS83jvj+KJui48JnKzp4njasHO7MqpUXqUDYs4AAADBANPhV5LaJ8+cV5RU
ZNeJk4XDTgoyf844+/HqqI3nFvJz422F6l0uQMyiDSeB1KnfaLaj3Z43p2vxdgipRXk1wX
W/KRqbIAVmabejxgdmjdtNl8BVqrHUvOZWiheOQ76GnV5ZW1KMIBsdknxbyNCYxHyJozeF
uJg2j/otp03A/7omq/bcaWo2fv+hwjOCIuV+Wr2G+RuyrjVjTSheaNCfHn2am8hnFa/TXN
JER3v2XSl5diijgBqfwZ9Bm+bTwM2sVQAAAMEAx3XM5T+J1rNW2VHpfGaACS9Yi9sfXzMB
iUDg80CU5OZB5rpF0ppfzcNDGYWf89UCyKBgKqW5pQSxyi1wa9uGl8S9mxeoRbkAV12Xn+
c3YW0rAYdqiEE+KZ+n9k/XsJUd8cRH5mJsYiVxf1UYe0fa1dIwAxwUrIAE0//fIaQelbK1
6G1j6H8lyvrFITiiXo7JBW1iAmE1E6u61/wRP1Iy92tz+IbEdOr8Ff1ErYynqGTbzPNb2o
HoufWF5oHT02mhAAAAFWJpbGx4QExBUFRPUC1CRk0wTkZJRgECAwQF
-----END OPENSSH PRIVATE KEY-----`

## Details of Github auto deploy setup

Using `git clone`, clone the repository https://github.com/adarsh249/CSE135_HW1 onto your local machine. Then, `cd` into the directory `CSE135_HW1`. From the file `deploy.yml`, on GitHub actions, we put in the secrets for HOST, USERNAME, PASSWORD, KEY. So now, when you make changes locally, you can commit and then use `git push` which will push to the GitHub repository. Then this will run the Github Actions script, which will copy the changed files to the remote server, hence, updating the remote server.

Additionally, one can clone the repository and set the new remote with `git remote add prod ssh://root@137.184.9.28/var/repo/CSE135_HW1.git`, and use `git push prod main` to push to both GitHub and the remote server.

## Username/password info for logging into site
usernames: 
- `adarsh` 
- `bill`
- `gary`
- `grader`

pass for all users: `123`

## Summary of changes to HTML file in DevTools after compression

There are no changes to the HTML file. This makes sense because users should not be able to see on their end the HTML file compressed. However, under Response Headers, we can see that Content-Encoding is gzip, so we are compressing pages.

## Summary of removing 'server' header

In `/etc/apache2/conf-available/security.conf`, we set `ServerTokens Full` and `ServerSignature On`. Then, in `/etc/apache2/apache2.conf`, we added lines 228 to 234 below:

```
<IfModule mod_headers.c>
Header always set Server "CSE 135 Server"
</IfModule>

<IfModule mod_security2.c>
SecServerSignature "CSE 135 Server"
</IfModule>
```

These lines alawys set the home page's server signature and every path on the site, including error 404, to have a response header of "CSE 135 Server".

## Analytics Configuration

<https://matomo.cse151group111.online>
Username: root
Passowrd: 123

