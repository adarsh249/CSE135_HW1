/*Images Enabled or Disabled
let trackerImage = document.getElementById("trackerImage");
let userImagesEnabled;
if(trackerImage.width == 1){
    userImagesEnabled = true;
    console.log("Images Enabled: " + imagesEnabled);
}
else {
    userImagesEnabled = false;
    console.log("Images Enabled: " + imagesEnabled);
}
let trackerCSS = document.getElementById("trackerCSS");
let userCSSEnabled = (trackerCSS.style.color === "white");
console.log("CSS Enabled: " + userCSSEnabled);

//I just put a noscript tag for Javascript Enabled
*/