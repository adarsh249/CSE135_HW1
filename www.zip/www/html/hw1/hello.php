<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Hello PHP</title>
</head>
<body>
    <h1>PHP Lives!</h1>
    <?php
      phpinfo();
     ?>
    
</body>
</html>
