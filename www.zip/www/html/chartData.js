const lineChartData = {
    series: [
        {
            values: [10, 20, 15, 25, 18, 30]
        },
        {
            values: [5, 8, 12, 10, 15, 20]
        },
        {
            values: [8, 12, 10, 15, 20, 25]
        }
    ]
};

const barChartData = {
    series: [
        {
            values: [20, 30, 15, 25, 10]
        },
        {
            values: [10, 15, 8, 12, 18]
        }
    ]
};

const pieChartData = {
    series: [
        {
            values: [30]
        },
        {
            values: [20]
        },
        {
            values: [50]
        }
    ]
};